const RPC = require('discord-rpc');
const rpc = new RPC.Client({
    transport: 'ipc'
});

rpc.on('ready', () => {
    rpc.setActivity({
        details: 'uh oh',
        state: 'electric points: [∞]',
        startTimestamp: new Date(),
        largeImageKey: 'playing_with_power',
        largeImageText: 'Uh oh not good',
        smallImageKey: 'playing_with_power',
        smallImageText: 'Uh oh not good',
        buttons: [{
            label: 'Eat electric socket',
            url: 'https://scratch.mit.edu/projects/735777476/',

        },{
            label: 'YouTube',
            url: 'https://youtube.com',
        }]
    });
    console.log('RPC is running');
})

rpc.login(
    {
        clientId: '1022626952835768322'
    }
)